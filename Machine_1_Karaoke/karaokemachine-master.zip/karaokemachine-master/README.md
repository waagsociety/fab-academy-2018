# karaokemachine
It's an Analog Karaoke Machine
